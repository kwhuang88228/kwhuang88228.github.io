# Problem Set 4B
# Name: Maya Lathi
# Collaborators:
# Time Spent:6:00
# Late Days Used: 0

import string

### HELPER CODE ###
def load_words(file_name):
    '''
    file_name (string): the name of the file containing 
    the list of words to load    
    
    Returns: a list of valid words. Words are strings of lowercase letters.
    
    Depending on the size of the word list, this function may
    take a while to finish.
    '''
    print("Loading word list from file...")
    # inFile: file
    inFile = open(file_name, 'r')
    # wordlist: list of strings
    wordlist = []
    for line in inFile:
        wordlist.extend([word.lower() for word in line.split(' ')])
    print("  ", len(wordlist), "words loaded.")
    return wordlist

def is_word(word_list, word):
    '''
    Determines if word is a valid word, ignoring
    capitalization and punctuation

    word_list (list): list of words in the dictionary.
    word (string): a possible word.
    
    Returns: True if word is in word_list, False otherwise

    Example:
    >>> is_word(word_list, 'bat') returns
    True
    >>> is_word(word_list, 'asdf') returns
    False
    '''
    word = word.lower()
    word = word.strip(" !@#$%^&*()-_+={}[]|\:;'<>?,./\" ")
    return word in word_list

def get_story_string():
    """
    Returns: a story in encrypted text.
    """
    f = open("story.txt", "r")
    story = str(f.read())
    f.close()
    return story

### END HELPER CODE ###

WORDLIST_FILENAME = 'words.txt'

class Message(object):
    def __init__(self, input_text):
        '''
        Initializes a Message object
                
        input_text (string): the message's text

        a Message object has two attributes:
            self.message_text (string, determined by input text)
            self.valid_words (list, determined using helper function load_words)
        '''
        self.message_text = input_text
        self.valid_words = load_words("words.txt")

    def get_message_text(self):
        '''
        Used to safely access self.message_text outside of the class
        
        Returns: self.message_text
        '''
        return self.message_text
        
    def get_valid_words(self):
        '''
        Used to safely access a copy of self.valid_words outside of the class.
        This helps you avoid accidentally mutating class attributes.
        
        Returns: a COPY of self.valid_words
        '''

        return list.copy(self.valid_words)
        
    def make_shift_dicts(self, input_shifts):
        '''
        Creates a list of dictionaries; each dictionary can be used to apply a
        cipher to a letter.
        The dictionary maps every uppercase and lowercase letter to a
        character shifted down the alphabet by the input shift. By shifted down, we mean 
        that if 'a' is shifted down by 2, the result is 'c.'

        The dictionary should have 52 keys of all the uppercase letters and
        all the lowercase letters only.

        input_shifts (list of integer): the amount by which to shift every letter of the
        alphabet. 0 <= shift < 26

        Returns: a list of dictionaries mapping letter (string) to
                 another letter (string).
        '''
        #initialize alphabet strings
        uppers = string.ascii_uppercase
        lowers = string.ascii_lowercase
        
        #separate shifts from list
        
        #create new dictionaries
        dict1 = {}
        dict2 = {}
        dict_list = [dict1, dict2]
        
        #loop through each dictionary: uppercases, then lowercases
        #initialize each char val to alphabet@ (orig char index + shift) %26
        
        for d in dict_list:
            shift = input_shifts[dict_list.index(d)] #index of d is index of shifts
            for u in uppers:
                d[u] = uppers[(uppers.find(u) + shift)%26]
            for l in lowers:
                d[l] = lowers[(lowers.find(l) + shift)%26]
        
        
        return dict_list
    
    def apply_shifts(self, shift_dicts):
        '''
        Applies the Caesar Cipher to self.message_text with letter shifts 
        specified in shift_dicts. Creates a new string that is self.message_text, 
        shifted down the alphabet by some number of characters, determined by 
        the shift value that shift_dicts was built with.       
        
        shift_dicts: list of dictionaries; each dictionary with 52 keys, mapping
            lowercase and uppercase letters to their new letters
            (as built by make_shift_dicts)

        Returns: the message text (string) with every letter shifted using the
            input shift_dicts 

        '''
        shifted_string = ""
        input_message = list(self.get_message_text())
        shift_even = shift_dicts[0]
        shift_odd = shift_dicts[1]
        
        for i in range(len(input_message)): #loop through indexes of string
            if not input_message[i].isalpha():
                shifted_string += input_message[i]
            else:
                orig_letter = input_message[i]
                if i%2 == 0: #even index
                    #use even shift dict
                    shifted_string += shift_even[orig_letter]
                else: #odd index, odd shift dict
                    shifted_string += shift_odd[orig_letter]
                
        return shifted_string
        
       

class PlaintextMessage(Message):
    def __init__(self, input_text, input_shifts):
        '''
        Initializes a PlaintextMessage object.       
        
        input_text (string): the message's text
        input_shifts (list of integers): the list of shifts associated with this message

        A PlaintextMessage object inherits from Message. It has five attributes:
            self.message_text (string, determined by input text)
            self.valid_words (list, determined using helper function load_words)
            self.shifts (list of integers, determined by input shifts)
            self.encryption_dicts (list of dictionaries, built using shifts)
            self.encrypted_message_text (string, encrypted using self.encryption_dict)

        '''
        Message.__init__(self, input_text)
        self.shifts = input_shifts
        self.encryption_dicts = Message.make_shift_dicts(self, input_shifts)
        self.encrypted_message_text = Message.apply_shifts(self, self.get_encryption_dicts())
    
    
    def get_shifts(self):
        '''
        Used to safely access self.shifts outside of the class
        
        Returns: self.shifts
        '''
        return self.shifts

    def get_encryption_dicts(self):
        '''
        Used to safely access a copy self.encryption_dicts outside of the class
        
        Returns: a COPY of self.encryption_dicts
        '''
        
        dict_copy = self.make_shift_dicts(self.shifts) #copies dictionaries
        return dict_copy
    
        
    def get_encrypted_message_text(self):
        '''
        Used to safely access self.encrypted_message_text outside of the class
        
        Returns: self.encrypted_message_text
        '''
        
        return self.apply_shifts(self.get_encryption_dicts())

    def modify_shifts(self, input_shifts):
        '''
        Changes self.shifts of the PlaintextMessage, and updates any other 
        attributes that are determined by the shift list.        
        
        input_shifts (list of length 2): the new shift that should be associated with this message.
        [0 <= shift < 26]

        Returns: nothing
        '''
        #basically reinitializes object attributes based on new input shifts
        self.shifts = input_shifts
        self.encryption_dicts = Message.make_shift_dicts(self, input_shifts)
        self.encrypted_message_text = Message.apply_shifts(self, self.get_encryption_dicts())
        

class CiphertextMessage(Message):
    def __init__(self, input_text):
        '''
        Initializes a CiphertextMessage object
                
        input_text (string): the message's text
        
        a CiphertextMessage object inherits from Message. It has two attributes:
            self.message_text (string, determined by input text)
            self.valid_words (list, determined using helper function load_words)
        '''
        self.message_text =input_text
        self.valid_words = load_words("words.txt")

    def decrypt_message(self):
        '''
        Decrypts self.message_text by trying every possible combination of shift
        values and finding the "best" one. 
        We will define "best" as the list of shifts that creates the maximum number
        of valid English words when we use apply_shifts(shifts)on the message text. 
        If [a, b] are the original shift values used to encrypt the message, then we 
        would expect [(26 - a), (26 - b)] to be the best shift values for
        decrypting it.

        Note: if multiple lists of shifts are equally good, such that they all create 
        the maximum number of valid words, you may choose any of those lists
        (and their corresponding decrypted messages) to return.

        Returns: a tuple of the best shift value list used to decrypt the message
        and the decrypted message text using that shift value
        '''
        max_count = 0
        best_shifts = []
        best_shift_dicts = {}
    
        #want to double loop through a and b 0-25
        for a in range (26):
            for b in range (26):
                
        #create shift dicts with new shifts
                temp_decrypt_shifts = [26-a, 26-b]
        #apply shifts to message, new string
                temp_shift_dicts = self.make_shift_dicts(temp_decrypt_shifts)
                temp_decrypt_message = Message.apply_shifts(self, temp_shift_dicts )
                #= self.apply_shifts(temp_shift_dicts)
        #split string at spaces
                words = temp_decrypt_message.split(" ")
        #check if the strings are valid words (use isword func)
        #count number of valid words made  by given shifts

                count = 0
                for word in words:
                    if is_word(self.get_valid_words(), word):
                        count += 1
                if count >= max_count:
        #store best shifts

                    max_count = count
                    best_shifts = [26-a, 26-b]
                    best_shift_dicts = self.make_shift_dicts([26-a, 26-b])
        #return best shifts + mesasge
        new_message = self.apply_shifts(best_shift_dicts)
        return (best_shifts, new_message)


def test_plaintext_message():
    '''
    Write two test cases for the PlaintextMessage class here. 
    Each one should handle different cases (see handout for
    more details.) Write a comment above each test explaining what 
    case(s) it is testing. 
    '''

    # This test is checking encoding a lowercase string with punctuation in it. 
    plaintext = PlaintextMessage('hello, hello, hello!', [2,3])
    print("Input: hello, hello, hello!", [2,3])
    print('Expected Output: jhnoq, kgnor, jhnoq!')
    print('Actual Output:', plaintext.get_encrypted_message_text())

    #This test is checking encoding a mixed-case word with numbers in it.
    plaintext2 = PlaintextMessage('The name IS b0nd', [9, 2])
    print("Input: The name IS b0nd")
    print('Expected Output: Cjn wcvg KB k0wf')
    print('Actual Output:', plaintext2.get_encrypted_message_text())
    
#    plaintext3 = PlaintextMessage('My name is Maya', [25, 1])
#    print(plaintext3.get_encrypted_message_text())

def test_ciphertext_message():
    '''
    Write two test cases for the CiphertextMessage class here. 
    Each one should handle different cases (see handout for
    more details.) Write a comment above each test explaining what 
    case(s) it is testing. 
    '''

#    #### Example test case (CiphertextMessage) ##### 
    
#   # This test is checking decoding a lowercase string with punctuation in it.
    ciphertext = CiphertextMessage('fbjim!')
    print("Input: fbjim!")
    print('Expected Output:', ([2, 3], 'hello!'))
    print('Actual Output:', ciphertext.decrypt_message())
    
    #testing proper nouns, case where a word isn't valid
    ciphertext2 = CiphertextMessage("Nx mblf jr Lbxb")
    print("Input: Nx mblf jr Lbxb")
    print("Expected Output:", ([25, 1], "My name is Maya"))
    print("Actual Output: ", ciphertext2.decrypt_message())
    
    

def decode_story():
    '''
    Write your code here to decode the story contained in the file story.txt.
    Hint: use the helper function get_story_string and your CiphertextMessage class.

    Returns: a tuple containing (best_shift, decoded_story)

    '''
    encrypted_story = get_story_string()
    
    story_obj = CiphertextMessage(encrypted_story)
    
    return story_obj.decrypt_message()

if __name__ == '__main__':

    # Uncomment these lines to try running your test cases 
    test_plaintext_message()
    test_ciphertext_message()

    # Uncomment these lines to try running decode_story_string()
#     best_shift, story = decode_story()
#     print("Best shift:", best_shift)
#     print("Decoded story: ", story)
#     
