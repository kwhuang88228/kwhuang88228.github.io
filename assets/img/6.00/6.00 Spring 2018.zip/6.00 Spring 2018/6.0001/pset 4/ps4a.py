# Problem Set 4A
# Name: Maya Lathi
# Collaborators: none
# Time Spent: started 30 minutes
# Late Days Used: 0

# Part A0: Data representation
# Fill out the following variables correctly.
# If correct, the tests named data_representation should pass.
tree1 = [[4, 10], 5] 
tree2 = [[15, 4], [[1, 2], 10]]
tree3 = [[12], [14, 6, 2], [19]]


# Part A1: Multiplication on tree leaves

def mul_tree(tree):
    """
    Recursively computes the product of all tree leaves.
    Returns an integer representing the product.

    Inputs
       tree: A list (potentially containing sublists) that
       represents a tree structure.
    Outputs
       total: An int equal to the product of all leaves of the tree.

    """
    #base case:
    if tree == []:
        return 1    
    
    #if tree is a full list
    #then if all leaves, multiply together
    #if there is a list, multiply fellow 
    #leaves by the breakdown of the list into leaves
    
    leaf_prod = 1
    
    for i in tree:
        if type(i) == int:
            leaf_prod *= i
        elif type(i) == list:
            leaf_prod *= mul_tree(i)
    
    return leaf_prod
        


# Part A2: Arbitrary operations on tree leaves

def addem(a,b):
    """
    Example operator function.
    Takes in two integers, returns their sum.
    """
    return a + b

def prod(a,b):
    """
    Example operator function.
    Takes in two integers, returns their product.
    """
    return a * b

def op_tree(tree, op, base_case):
    """
    Recursively runs a given operation on tree leaves.
    Return type depends on the specific operation.

    Inputs
       tree: A list (potentially containing sublists) that
       represents a tree structure.
       op: A function that takes in two inputs and returns the
       result of a specific operation on them.
       base_case: What the operation should return as a result
       in the base case (i.e. when the tree is empty).
    """
    #base case, generalized
    if tree == []:
        return base_case    
    
    #if tree is a full list
    #then if all leaves, perform op on all leaves
    #if there is a "leaf" is a list, perform op on breakdown of list on fellow leaves 
    
    op_result = base_case
    
    for i in tree:
        if type(i) == int:
            op_result = op(op_result, i)
        elif type(i) == list:
            op_result = op(op_result, op_tree(i, op, base_case))
    
    return op_result
    

# Part A3: Searching a tree

def search_odd(a, b):
    """
    Operator function that searches for odd values within its inputs.

    Inputs
        a, b: integers or booleans
    Outputs
        True if either input is equal to True or odd, and False otherwise
    """
    if type(a) == int and type(b) == int:
        #ret true if either are odd
        if a % 2 ==1 or b%2 == 1:
            return True
    
    if type(a) == bool and type(b) ==bool:
        #ret true if either are true
        if a or b:
            return True
    
    if type(a) == int and type(b) == bool:
        if a%2 == 1 or b:
            return True
        #return true if bool is true, or int is odd, or both
    if type(b) == int and type(a)  == bool:
        if b%2 == 1 or a:
            return True
    return False
    

if __name__ == '__main__':
    # You can use this part for your own testing and debugging purposes.
    # Do not erase the pass statement below.
#    print(mul_tree(tree1)) # should be 200
#    print(mul_tree(tree2))  # should be 1200
#    print(mul_tree(tree3))  # should be 38304
    pass