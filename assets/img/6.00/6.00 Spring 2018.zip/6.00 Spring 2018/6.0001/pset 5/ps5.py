
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  1 15:32:26 2018

@author: phillipferguson
"""

"""
# Problem Set 5
# Name: Maya Lathi
# Collaborators:
# Time: 2:30
"""

from PIL import Image
import numpy

def generate_matrix(color):
    """
    Generates a transformation matrix for the specified color.
    Inputs:
        color: string with exactly one of the following values:
               'red', 'blue', 'green', or 'none'
    Returns:
        matrix: a transformation matrix corresponding to
                deficiency in that color
    """
    # You do not need to understand exactly how this function works.
    if color == 'red':
        c = [[.567, .433, 0],[.558, .442, 0],[0, .242, .758]]
    elif color == 'green':
        c = [[0.625,0.375, 0],[ 0.7,0.3, 0],[0, 0.142,0.858]]
    elif color == 'blue':
        c = [[.95, 0.05, 0],[0, 0.433, 0.567],[0, 0.475, .525]]
    elif color == 'none':
        c = [[1, 0., 0],[0, 1, 0.],[0, 0., 1]]
    return c

def matrix_multiply(m1,m2):
    """
    Multiplies the input matrices.
    Inputs:
        m1,m2: the input matrices
    Returns:
        result: matrix product of m1 and m2
        in a list of floats
    """

    product = numpy.matmul(m1,m2)
    if type(product) == numpy.int64:
        return float(product)
    else:
        result = list(product)
        return result





def convert_image_to_pixels(image):
    """
    Takes an image (must be inputted as a string
    with proper file attachment ex: .jpg, .png)
    and converts to a list of tuples representing pixels.
    Each pixel is a tuple containing (R,G,B) values.

    Returns the list of tuples.

    Inputs:
        image: string representing an image file, such as 'lenna.jpg'
        returns: list of pixel values in form (R,G,B) such as
                 [(0,0,0),(255,255,255),(38,29,58)...]
    """
    im = Image.open(image)
    pixels = im.getdata()
    return pixels

def convert_pixels_to_image(pixels,size):
    """
    Creates an Image object from a inputted set of RGB tuples.

    Inputs:
        pixels: a list of pixels such as the output of
                convert_image_to_pixels.
        size: a tuple of (width,height) representing
              the dimensions of the desired image. Assume
              that size is a valid input such that
              size[0] * size[1] == len(pixels).
    returns:
        img: Image object made from list of pixels
    """
    im = Image.new("RGB", size)
    im.putdata(pixels)
    return im

def apply_filter(pixels, color):
    """
    pixels: a list of pixels in RGB form, such as [(0,0,0),(255,255,255),(38,29,58)...]
    color: 'red', 'blue', 'green', or 'none', must be a string representing the color
    deficiency that is being simulated.
    returns: list of pixels in same format as earlier functions,
    transformed by matrix multiplication
    """
    color_mat = generate_matrix(color) #create new matrix for color transformation
    new_pixel_list = []
    for p in pixels:
        new_pix = matrix_multiply(color_mat, p) #creates new tuple representing augmented color vals
        for i in range(len(new_pix)):
            new_pix[i] = int(new_pix[i]) #cast new pixel component as an int
        new_pixel_list.append(tuple(new_pix))
    return new_pixel_list
    

def reveal_BW_image(filename):
    """
    Extracts the hidden image in the least significant bit
    of each pixel in the specified image.
    Inputs:
       filename: string, input file to be processed
    returns:
       result: an Image object containing the hidden image
    """
    orig_image = Image.open(filename)
    orig_pixels = convert_image_to_pixels(filename)
    bw_pix = []
    
    for p in orig_pixels:
    
        if p%2 == 1:#pixels w/ odd least sig. bits becomes white
            bw_pix.append((255, 255, 255))
        else: #pixels w/ even least sig. bits become black
            bw_pix.append((0, 0, 0))
            
    return convert_pixels_to_image(bw_pix, orig_image.size)

def reveal_RGB_image(filename):
    """
    Extracts the hidden image in the 2 least significant bits
    of each pixel in the specified color image.
    Inputs:
        filename: string, input RGB file to be processed
    Returns:
        result: an Image object containing the hidden image
    """
    
    orig_image = Image.open(filename)
    orig_pixels = convert_image_to_pixels(filename)
    mod_pixels = []
    for p in orig_pixels: #iterate through original pixels
        rgb_pix = [] #use a list to make additions easier
        for comp in p: #iterate through pixel components
            #divide second least significant digits into different colors
            mod = comp%4
            if mod == 0:
                rgb_pix.append(0)
            elif mod == 1:
                rgb_pix.append(85)
            elif mod == 2:
                rgb_pix.append(170)
            elif mod == 3:
                rgb_pix.append(255)
        rgb_pix = tuple(rgb_pix) #recast as tuole
        mod_pixels.append(rgb_pix)
    
    return convert_pixels_to_image(mod_pixels, orig_image.size)

def main():

    # UNCOMMENT the following 8 lines to test part 1

#    im = Image.open('image_15.png')    
#    width, height = im.size
#    pixels = convert_image_to_pixels('image_15.png')
#    image = apply_filter(pixels,'none')
#    im = convert_pixels_to_image(image, (width, height))
#    im.show()
#    new_image = apply_filter(pixels,'red')
#    im2 = convert_pixels_to_image(new_image,(width,height))
#    im2.show()
#    

    # No tests for part 2. Try to find the secret images!
#    secret_bw = reveal_BW_image("hidden1.bmp")
#    secret_bw.show()
    secret_rgb = reveal_RGB_image("hidden2.bmp")
    secret_rgb.show()

if __name__ == '__main__':
    main()