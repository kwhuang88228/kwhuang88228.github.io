#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 10 21:02:28 2018

@author: mayalathi
"""

#Problem Set 1B
#Name: Maya Lathi
#Collaborators: 
#Time spent: 0:05


annual_salary = float(input("Enter your annual salary: " ))
portion_saved = float(input("Enter the portion of your salary to save, as a decimal: "))
total_cost = float(input("Enter the cost of your dream home: " ))
semi_annual_raise = float(input("Enter the semi_annual raise, as a decimal: "))

portion_down_payment = .15
current_savings = 0
r = .02
months = 0

while (current_savings < portion_down_payment*total_cost):
    current_savings += current_savings*r/12
    current_savings += annual_salary/12*portion_saved
    months += 1
    if months%6 == 0:
        annual_salary *= (semi_annual_raise + 1)

print("Number of months: ", months)
