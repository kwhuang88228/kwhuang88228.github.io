def part_b(annual_salary, portion_saved, total_cost, semi_annual_raise):
	
	portion_down_payment = .15
	current_savings = 0
	r = .02
	months = 0
	
	while (current_savings < portion_down_payment*total_cost):
	    current_savings += current_savings*r/12
	    current_savings += annual_salary/12*portion_saved
	    months += 1
	    if months%6 == 0:
	        annual_salary *= (semi_annual_raise + 1)
	
	print("Number of months: ", months)
	return months