#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 10 21:17:25 2018

@author: mayalathi
"""

#Problem Set 1C
#Name: Maya Lathi
#Collaborators: 
#Time spent: 1:15

initial_deposit = float(input("Enter the initial deposit: "))
money_needed = 800000*.3


current_savings = 0
low = 0
high = 10000
best_r = (low + high)/20000
steps = 0

if money_needed < initial_deposit:
    print ("Best savings rate: ", 0)

else:
   while abs(money_needed - current_savings) > 100:
       
       steps += 1    
    
       best_r = (low+high)//2
        
       current_savings = initial_deposit*(1+best_r/120000)**36
       
        
       if initial_deposit*(1+1/12)**36 < money_needed:
          
           best_r = 'It is not possible to pay the down payment in three years.'
           break
       
       if current_savings < money_needed:
           low = best_r
    
       else: 
           high = best_r
        



if type(best_r) == str:
    print("no r possible", best_r)
else:
    best_r /=10000
    print("Best savings rate: ", best_r)

print("Steps in bisection search: ", steps)
        


