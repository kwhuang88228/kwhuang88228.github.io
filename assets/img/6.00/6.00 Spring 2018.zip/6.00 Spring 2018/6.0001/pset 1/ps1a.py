# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
#Problem Set 1A
#Name: Maya Lathi
#Collaborators: 
#Time spent: 0:15


annual_salary = float(input("Enter your annual salary: " ))
portion_saved = float(input("Enter the portion of your salary to save, as a decimal: "))
total_cost = float(input("Enter the cost of your dream home: " ))
portion_down_payment = .15
current_savings = 0
r = .02
months = 0

while (current_savings < portion_down_payment*total_cost):
    current_savings += current_savings*r/12
    current_savings += annual_salary/12*portion_saved
    months += 1

print("Number of months: ", months)