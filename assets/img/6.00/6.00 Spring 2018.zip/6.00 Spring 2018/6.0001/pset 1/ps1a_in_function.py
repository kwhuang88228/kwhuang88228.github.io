def part_a(annual_salary, portion_saved, total_cost):
	portion_down_payment = .15
	current_savings = 0
	r = .02
	months = 0
	
	while (current_savings < portion_down_payment*total_cost):
	    current_savings += current_savings*r/12
	    current_savings += annual_salary/12*portion_saved
	    months += 1
	
	print("Number of months: ", months)
	return months