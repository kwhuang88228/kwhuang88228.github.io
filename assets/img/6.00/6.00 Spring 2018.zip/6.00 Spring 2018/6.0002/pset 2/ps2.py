# 6.0002 Problem Set 5
# Graph optimization
# Name: Maya Lathi
# Collaborators: Sean Condon, Molly Humphreys, Will Rudebersits
# Time: 5.5 hrs

#
# Finding shortest paths through MIT buildings
#
import unittest
from graph import Digraph, Node, WeightedEdge

#
# PROBLEM 2: Building up the Campus Map
#
# PROBLEM 2a: Designing your graph
#
# What do the graph's nodes represent in this problem? What
# do the graph's edges represent? Where are the distances
# represented?
#
# ANSWER: Nodes represent buildings, the edges represent valid paths between buildings (i.e. not walking through walls).
#         The distances are represented in the third integer as the distance between the two buildings
#


# PROBLEM 2b: Implementing load_map
def load_map(map_filename):
    """
    Parses the map file and constructs a directed graph

    Parameters:
        map_filename : name of the map file

    Assumes:
        Each entry in the map file consists of the following four positive
        integers, separated by a blank space:
            From To TotalDistance
        e.g.
            32 76 54 
        This entry would become an edge from 32 to 76.

    Returns:
        a directed graph representing the map
    """
    print("Loading map from file...")
    d = Digraph()
    file = open(map_filename)
    
    for line in file:
        #three integers
        ints = line.split(' ')
        src = ints[0]
        dest = ints[1]
        dist = ints[2][:-1]
        
        try:
            d.add_node(src)
        except ValueError:
            pass
        
        try:
            d.add_node(dest)
        except ValueError:
            pass
        
        e = WeightedEdge(src, dest, dist)
        d.add_edge(e)
    
    return d

# PROBLEM 2c: Testing load_map
# Include the lines used to test load_map below, but comment them out

dorms = load_map("test_load_map.txt")
print(dorms)


# PROBLEM 3: Finding the Shorest Path using Optimized Search Method
#
# PROBLEM 3a: Objective function
#
# What is the objective function for this problem? What are the constraints?
#
# ANSWER: The objective function for this problem is the distance between a start and end node.
# We are trying to minimize this distance.
# The constraints are whether or not a path exists that connects a start and end node.
#

# PROBLEM 3b: Implement add_node_to_path
def add_node_to_path(node, path):
    """
    Adds the name of the node to the copy of the list of strings inside the 
    safely copied version of the path. 
    Leave the other two items in path unchanged (total distance traveled and 
    total number of buildings).
    
    Parameters:
        path: list composed of [[list of strings], int, int]
            Represents the current path of nodes being traversed. Contains
            a list of node names, total distance traveled, and total
            number of buildings.
        node: Node 
            Representing a building being added to the path
            
    Returns:
        A safely copied version of path with the node name added to the end of 
        the first element.
    """
    node = Node(node)
    #create a complete copy of path
    path_copy_nodes = path[0].copy()
    
    #add node
    path_copy_nodes.append(node.get_name())
    
    #return reconstructed list
    return[path_copy_nodes, path[1], path[2]]

# PROBLEM 3c: Implement get_best_path
def get_best_path(digraph, start, end, path, max_buildings, best_dist,
                  best_path):
    """
    Finds the shortest path between buildings subject to constraints.

    Parameters:
        digraph: instance of Digraph or one of its subclasses
            The graph on which to carry out the search
        start: string
            Building number at which to start
        end: string
            Building number at which to end
        path: list composed of [[list of strings], int, int]
            Represents the current path of nodes being traversed. Contains
            a list of node names, total distance traveled, and total
            number of buildings.
        max_buildings: int
            Maximum number of buildings a path can visit
        best_dist: int
            The smallest distance between the original start and end node
            for the initial problem that you are trying to solve
        best_path: list of strings
            The shortest path found so far between the original start
            and end node.

    Returns:
        A tuple of the form (best_dist, best_path).
        The first item is an integer, the length (distance traveled)
        of the best path.
        The second item is the shortest-path from start to end, represented by
        a list of building numbers (in strings).

        If there exists no path that satisfies max_total_dist and
        max_buildings constraints, then best_path is None.
    """
        
    #BASE CASE: if start or end are not valid nodes: raise an error
    if not digraph.has_node(start) or not digraph.has_node(end):
        raise ValueError

    #BASE CASE: elif start and end are the same node:
    elif start == end:
        #update the appropriate variables
        return (path[1], path[0])
    
    #BASE CASE: if there are no more buildings left to check
    elif path[2] > max_buildings:
        return (best_dist, None)
    
    #CONTINUE TO RECURSIVE STEP
    else:
        
        #loop through associated edges for starting node
        for edge in digraph.get_edges_for_node(start):

#            print("branching off " + str(edge))

            #identify child 
            child = edge.get_destination()
#            print("child " + str(child))

            #CHECK: either no best path has been found or there's a chance this step will be efficient// and not a cycle // and there's buildings left
            if (best_path == None or path[1] + int(edge.get_total_distance()) <= best_dist) and (child not in path[0]) and (path[2]+ 1 <= max_buildings):

                #UPDATE PATH by making a new list of [path, dist, buildings visited]
                
                updated_path = add_node_to_path(child, path) #add node to path
                updated_path[1] += int(edge.get_total_distance()) #add path distance
                updated_path[2] += 1 # add number of buildings visited on this path
                
                #CREATE NEW TUPLE with updated path, branching from child
                (best_d_recur, best_p_recur) = get_best_path(digraph, child, end, updated_path, max_buildings, best_dist, best_path)

                #COMPARE if the distance found w/ branching is better
                if best_d_recur <= best_dist:
                    best_dist = best_d_recur
                    best_path = best_p_recur
                        
#return the shortest path
    return (best_dist, best_path)
    


### USED FOR TESTING. PLEASE DO NOT CHANGE THIS FUNCTION.
def directed_dfs(digraph, start, end, max_total_dist, max_buildings):
    """
    Finds the shortest path from start to end using a directed depth-first
    search. The total distance traveled on the path must not
    exceed max_total_dist, and the number of buildings on this path must
    not exceed max_buildings.

    Parameters:
        digraph: instance of Digraph or one of its subclasses
            The graph on which to carry out the search
        start: string
            Building number at which to start
        end: string
            Building number at which to end
        max_total_dist: int
            Maximum total distance on a path
        max_buildings: int
            Maximum number of buildingss a path can visit

    Returns:
        The shortest-path from start to end, represented by
        a list of building numbers (in strings).

        If there exists no path that satisfies max_total_dist and
        max_buildings constraints, then raises a ValueError.
    """
    best_path = None
    path = [[start], 0, 1]  # begin at start node with 0 distance
    best_dist, best_path = get_best_path(digraph, start, end, path,
                                         max_buildings, max_total_dist,
                                         best_path)
    if best_path is None:
        raise ValueError("No path from {} to {}".format(start, end))
    return best_path

