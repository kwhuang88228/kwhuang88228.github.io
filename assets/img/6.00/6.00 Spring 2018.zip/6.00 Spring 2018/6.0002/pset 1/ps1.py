###########################
# 6.0002
# Problem Set 1
# Name: Maya Lathi
# Collaborators: OH
# Time: 10.5 hours
#


from ps1_partition import get_partitions
import time
import copy

# Problem 1
def load_cows(filename):
    """
    Read the contents of the given file. Assumes the file contents contain data
    in the form of comma-separated values with the weight and cow name per line.

    Parameters:
    filename _ the name of the data file as a string

    Returns:
    a dictionary containing cow names (string) as keys, and the corresponding
    weight (int) as the value, e.g. {'Matt': 3, 'Kaitlin': 3, 'Katy': 5}
    """
    f = open(filename, 'r') #opens file in reading mode
    cow_dict = {} #empty dict to store cow vals
    
    for line in f: #loop over lines in the file
        els = line.split(",") #separates names and weights into a list
        weight = els[0] #weight is 0th el of list
        name = els[1][:-1] #name is 1th el of list, file includes /n new line indicator (remove that using string slicing)
        cow_dict[name] = int(weight) #assign weight cast as an int as the value for the name as the key
    
    return cow_dict #return the dict

# Problem 2
def greedy_cow_trips(cows, limit=10):
    #QUESTIONS: to break ties arbitrarily, how necessary?
    """
    Uses a greedy heuristic to determine an allocation of cows that attempts to
    minimize the number of spaceship trips needed to transport all the cows. The
    returned allocation of cows may or may not be optimal.
    The greedy heuristic should follow the following method:

    1. As long as the current trip can fit another cow, add the largest cow that will fit
        to the trip
    2. Once the trip is full, begin a new trip to transport the remaining cows

    Does not mutate the given dictionary of cows.

    Parameters:
    cows _ a dictionary of names (string), weights (int)
    limit _ weight limit of the spaceship (an int)

    Returns:
    A list of lists, with each inner list containing the names of cows
    transported on a particular trip and the overall list containing all the
    trips
    """
    cow_copy = cows.copy() #copy input dict
    total_trips = [] #will store individual trips as lists
    
    while (len(cow_copy) > 0): #continue finding new trips until there are no more cows left
        trip = [] #initialize trip
        trip_sum = 0 #initialize sum of weights for the trip as 0
        trip_cows = cow_copy.copy() #copies the dictionary with all remaining cows
        
        while (len(trip_cows) > 0): #executes while there are still cows left in trip_cows
            max_key = find_max_key(trip_cows) #accesses helper function to find key with maximum value in trip_cows
            if trip_sum + trip_cows[max_key] <= limit: #if there is room left on the ship for this cow's val
                trip.append(max_key) #add cow to this trip
                trip_sum += trip_cows[max_key] #add weight to the trip weight
                cow_copy.pop(max_key, None) #remove cow from total available options (cow_copy) b/c it's already been added to a trip
            trip_cows.pop(max_key, None) #regardless, remove cow from trip options b/c its either on the trip or too big for the trip
            
        total_trips.append(trip) #add trip to the total trips
    
    return total_trips #return the total trips
            
    
def find_max_key(d): #helper function, finds the key in the dictionary with the largest value
    return max(d, key = lambda k: d[k]) #d is iterable, key accesses the value
       

# Problem 3
def brute_force_cow_trips(cows, limit):
    """
    Finds the allocation of cows that minimizes the number of spaceship trips
    via brute force.  The brute force algorithm should follow the following method:

    1. Enumerate all possible ways that the cows can be divided into separate trips.
        Use the given get_partitions function in ps1_partition.py to help you!
    2. Select the allocation that minimizes the number of trips without making any trip
        that does not obey the weight limitation.

    Does not mutate the given dictionary of cows.

    Parameters:
    cows _ a dictionary of names (string), and weights (int)
    limit _ weight limit of the spaceship (an int)

    Returns:
    A list of lists, with each inner list containing the names of cows
    transported on a particular trip and the overall list containing all the
    trips
    """
    cow_copy = cows.copy()
    best_trip = []
    min_trips = len(cow_copy) #initialize minimum trips as length because true value must be <=
    for partition in get_partitions(cow_copy): #iterate over all possible partitions
       ##print(partition) takes about 10 seconds to run
        valid_weights = True #will be used to check if there are any invalid trips by weight
        for l in partition: #iterate over internal lists
            inner_sum = 0 #initialize trip weight at 0
            for k in l: #for k (key) in each internal list w/in the partition
                inner_sum += cow_copy[k] #add associated value to the sum
            if inner_sum > limit: #check the inner sum against the limit
                valid_weights = False #if any list doesn't pass this test, valid_weights = False, invalidating that partition
        
        if valid_weights: #checking if all weights valid
            if len(partition) < min_trips: #check if its a better trip
                min_trips = len(partition)
                best_trip = partition
    
    return best_trip

# Problem 4
def compare_cow_trips_algorithms():
    """
    Using the data from ps1_cow_data.txt and the specified weight limit, run your
    greedy_cow_trips and brute_force_cow_trips functions here. Use the
    default weight limits of 10 for both greedy_cow_trips and
    brute_force_cow_trips.

    Print out the number of trips returned by each method and how long each
    method takes to run in seconds.

    Returns:
    Does not return anything.
    """
    cow_data = load_cows("ps1_cow_data.txt")
    limit = 10
    
    #greedy cow
    g_start = time.time()
    gct = greedy_cow_trips(cow_data, limit)
    g_end = time.time()
    print("Greedy trips:", len(gct), "// time:", g_end - g_start, "secs")
    
    #brute force
    b_start = time.time()
    bfct = brute_force_cow_trips(cow_data, limit)
    b_end = time.time()
    print("Brute force trips:", len(bfct), "// time:", b_end - b_start, "secs")

# Problem 5
def dp_max_cows_on_trip(cow_weights, target_weight, memo = {}):
    """
    Find largest number of cows that can be brought back. Assumes there is
    an infinite supply of cows of each weight in cow_weights.

    Parameters:
    cow_weights   _ tuple of ints, available cow weights sorted from smallest to
                    largest value (d1 < d2 < ... < dk)
    target_weight _ int, amount of weight the spaceship can carry
    memo          _ dictionary, OPTIONAL parameter for memoization (you may not
                    need to use this parameter depending on your implementation,
                    don't delete though!)

    Returns:
    int, largest number of cows that can be brought back whose weight
    equals target_weight
    None, if no combinations of weights equal target_weight
    """
    
    #problems I had: not storing recursive depth, not using memo aggressively enough
    
    
    
    if target_weight in memo: #already been calculated, return max number of cows to meet that target weight, already in memo
        return memo[target_weight] #access memo
    
    elif target_weight == 0: #target weight is 0, 0 cows needed
        memo[0] = 0 #store in memo
        return 0

    elif target_weight < cow_weights[0]:  #if desired weight is smaller than given, impossible
        memo[target_weight] = None
        return None #want to bounce the tree back up a step
    
    best = 0 #storing the best recursion depth outside of for loop
    
    for weight in cow_weights: #looping through branch options (cow weights)
        
        try_weight = target_weight - weight #weight to evaluate is target weight minus branch weight
        
        
        shrinky = dp_max_cows_on_trip(cow_weights, try_weight, memo) #will return something based on value of lower branch
        
        if shrinky == None: #if the next lowest branch returns a None, the directly above notch should be a None (None --> impossible)
            memo[try_weight] = None #add to memo
            
        else:
            if shrinky + 1 > best: #best depth is one more than the depth at shrinky b/c including this node
                best = shrinky + 1
        
        memo[try_weight] = shrinky #change the memo val at try_weight to whatever shrinky returned
                
    if best == 0: #in the case where best is unchanged, no possbile branches below
        memo[target_weight] = None #change memo
        return None
    else: #memo found a lower branch
        memo[target_weight] = best #change memo
        return best
            
                
    
        
        

# EXAMPLE TESTING CODE, feel free to add more if you'd like
if __name__ == '__main__':

# Problem 1
#    cow_weights = load_cows('ps1_cow_data.txt')
#    print(cow_weights)
# Problem 2
#    print(greedy_cow_trips(cow_weights, 10))
# Problem 3
#    print(brute_force_cow_trips(cow_weights, 10))
# Problem 4
#    compare_cow_trips_algorithms()
# Problem 5
     cow_weights = (3, 5, 8, 9)
     n = 64
     print("Cow weights = (3, 5, 8, 9)")
     print("n =", n)
     print(dp_max_cows_on_trip(cow_weights, n))
#     print("Expected ouput: 20 (3 * 18 + 2 * 5 = 64)")
#     print("Actual output:", dp_max_cows_on_trip(cow_weights, n))
    # print()
    
